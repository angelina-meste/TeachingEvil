# COLLEGE goal: get 15 credits to move on and begin teachig

print()

def exam_room():
    print("You're running out of time - you find your exam room and sit down. Once everyone settled \nthe teacher hands out the papers and you begin writing.")

def washroom():
    print("You figure you have enough time to freshen up before your exam. \nYou enter the washroom to find a piece of paper jammed behind the sink.")

def on_note():
    print("1. 3051 \n2. ---mal \n3. ro---- hoo-- \n4. same \n5. same - 6 \n6. 8 8-2 8-4 00")
    

def want_note():
    washroom()
    print()

    print("It reads: \n")
    on_note()
    print("This can come in handy.")
    print()

    exam_room()
    print()
    exam_note()

def begin():
    # VARIABLES / IMPORTS

    import time

    done = False

    print("After spending your whole childhood taking care of children,\nyou knew you wanted to be a teacher! Which is why you are here - \nat teachers college.")
    time.sleep(4)

    print()

    print("PLEASE BE ADVISED: the members of this group are not experts in what goes on at teachers college.")
    time.sleep(3)

    print()
    print("2 years later...")
    print()


    print("You got through teachers college, but now it's time for your \nfinal exam... If you can't pass 12 of the following 15 questions, you \nwon't be able to teach, and it's game over for you.")
    time.sleep(5)

    print()

    while done == False:

        ask = input("Do you want to freshen up before exams? \n[1] Yes \n[2] No \nEnter choice: ")

        print()
        
        if ask == "1" or ask.lower() == "yes":
            want_note()
            done = True
        elif ask == "2" or ask.lower() == "no":
            exam_room()
            print()
            exam()
            done = True
        else:
            print("Not a valid response - try again.")
            done = False


def note():
    # VARIABLES / IMPORTS
    import random
    import sys
    import time
    print()

    ask_note = input("Do you want to look at the note again? \n[1] Yes \n[2] No \nEnter choice: ")
    
    if ask_note == "1" or ask_note.lower() == "yes":
        if random.randrange(1,3) == 1:
            print("The teacher catches you looking at the note and takes the exam away. \nYou get kicked out of the school forever. \nGame over.")
            time.sleep(4)
            sys.exit()
        else:
            print()
            on_note()
            print()
    else:
        print()
      

def exam_note():

    # VARIABLES / IMPORTS

    # creates pauses
    import time
    import sys

    # checks if game is done
    done = False
    game = False

    # credit variable 
    credits = 0

    # check validation

    check = False
    
    # INTRODUCTION
    while game == False:
        print()

        # COLLEGE -> 15 exam questions

        # one
        while True:
            try:
                exam = int(input("What year was the Mona Lisa painted? "))
                break
            except ValueError:
                print("That isn't a year - try again.")

        if exam == 1503:
            print("Correct!")
            credits += 1
        else: 
            print("Wrong.")

        print()
        
        note()

        # two
        while True:
            try:
                exam = input("What kingdom do humans fall under? ")
                break
            except ValueError:
                print("That isn't a proper kingdom - try again.")

        if  exam.lower() == "animal" or exam.lower() == "animal kingdom" or exam.lower() == "animalia":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        note()

        # three
        while True:
            try: 
                exam = input("Who originally discovered cells? ")
                break
            except ValueError:
                print("That isn't a proper response - try again.")
        if exam.lower() == "robert hooke":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()
    
        note()


        # four
        while True:
            try:
                exam = int(input("What is the square root of: 9x9? "))
                break
            except ValueError:
                print("That isn't a number - try again.")
        if exam == 9:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        note()


        # five
        while True:
            try:
                exam = int(input("How many curves does the standard paper clip have? "))
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam == 3:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        note()


        # six 
        while True:
            try: 
                exam = int(input("How many seconds are in a day? "))
                break
            except ValueError:
                print("Only use numbers - try again.")
        if exam == 86400:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()
        
        # seven 
        while True:
            try:
                exam = input("What is the hottest planet in our solar system? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "venus":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # eight
        while True:
            try:
                exam = input("What is the worlds oldest competetive sport? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "wrestling":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # nine
        while True:
            try:
                exam = int(input("How many bones does a shark have? "))
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam == 0:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # ten
        while True:
            try:
                exam = input("At the minimum - how long should your exercise warm-up last? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "10-15 minutes" or exam.lower() == "10 minutes":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # eleven
        while True:
            try:
                exam = input("How much of the average person's body weight is muscle? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam == "40%" or exam == "40":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # twelve
        while True:
            try:
                exam = input("What famous painter was also a sculptor, architect, and engineer? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "leonardo da vinci" or exam.lower() == "da vinci":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # thirteen
        while True:
            try:
                exam = input("What is the art term for colour? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "hue":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # fourteen
        while True:
            try:
                exam = input("What do hurricanes form over? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "warm water":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # fifteen
        while True:
            try:
                exam = input("Can Pi be a fraction? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "no":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")
            print()

        while done == False:
            if credits >= 12:
                    print(f"Congraulations! You passed with {credits}/15. Go on and get a job.")
                    time.sleep(1)
                    print()
                    done = True
                    game = True
            else:
                print(f"With {credits}/15, you didn't pass teachers college.")
                print()
                time.sleep(2)

                print()
                while check == False: 
                    again = input("Would you like to go through college again? \n[1] Yes\n[2] No\nEnter choice: ")

                    print()

                    if again.lower() == "yes" or again == "1":
                        check = True
                        done = True
                        print()
                        game = False
                    elif again.lower() == "no" or again == "2":
                        print()
                        print("Game Over.")
                        check = True
                        done = True
                        game = True
                        sys.exit
                    else:
                        print()
                        print("Incorrect response - try again.")
                        time.sleep(2)
                        print()
                        check = False


def exam():
    # VARIABLES / IMPORTS

    # creates pauses
    import time


    import sys

    # checks if game is done
    done = False
    game = False

    # choice validation
    check = False

    # credit variable 
    credits = 0
    
    # INTRODUCTION
    while game == False:
        print()

        # COLLEGE -> 15 exam questions

        # one
        while True:
            try:
                exam = int(input("What year was the Mona Lisa painted? "))
                break
            except ValueError:
                print("That isn't a year - try again.")

        if exam == 1503:
            print("Correct!")
            credits += 1
        else: 
            print("Wrong.")

        print()

        # two
        while True:
            try:
                exam = input("What kingdom do humans fall under? ")
                break
            except ValueError:
                print("That isn't a proper kingdom - try again.")

        if  exam.lower() == "animal" or exam.lower() == "animal kingdom" or exam.lower() == "animalia":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # three
        while True:
            try: 
                exam = input("Who originally discovered cells? ")
                break
            except ValueError:
                print("That isn't a proper response - try again.")
        if exam.lower() == "robert hooke":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # four
        while True:
            try:
                exam = int(input("What is the square root of: 9x9? "))
                break
            except ValueError:
                print("That isn't a number - try again.")
        if exam == 9:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # five
        while True:
            try:
                exam = int(input("How many curves does the standard paper clip have? "))
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam == 3:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # six 
        while True:
            try: 
                exam = int(input("How many seconds are in a day? "))
                break
            except ValueError:
                print("Only use numbers - try again.")
        if exam == 86400:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()
        
        # seven 
        while True:
            try:
                exam = input("What is the hottest planet in our solar system? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "venus":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # eight
        while True:
            try:
                exam = input("What is the worlds oldest competetive sport? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "wrestling":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # nine
        while True:
            try:
                exam = int(input("How many bones does a shark have? "))
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam == 0:
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # ten
        while True:
            try:
                exam = input("At the minimum - how long should your exercise warm-up last? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "10-15 minutes" or exam.lower() == "10 minutes":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # eleven
        while True:
            try:
                exam = input("How much of the average person's body weight is muscle? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam == "40%" or exam == "40":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # twelve
        while True:
            try:
                exam = input("What famous painter was also a sculptor, architect, and engineer? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "leonardo da vinci" or exam.lower() == "da vinci":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # thirteen
        while True:
            try:
                exam = input("What is the art term for colour? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "hue":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # fourteen
        while True:
            try:
                exam = input("What do hurricanes form over? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "warm water":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")

        print()

        # fifteen
        while True:
            try:
                exam = input("Can Pi be a fraction? ")
                break
            except ValueError:
                print("Invalid answer - try again.")
        if exam.lower() == "no":
            print("Correct!")
            credits += 1
        else:
            print("Wrong.")
            print()

        while done == False:
            if credits >= 12:
                    print(f"Congraulations! You passed with {credits}/15. Go on and get a job.")
                    time.sleep(1)
                    print()
                    done = True
                    game = True

            else:
                print(f"With {credits}/15, you didn't pass teachers college.")
                print()
                time.sleep(2)

                print()
                while check == False: 
                    again = input("Would you like to go through college again? \n[1] Yes\n[2] No\nEnter choice: ")

                    print()

                    if again.lower() == "yes" or again == "1":
                        print()
                        done = True
                        check = True

                        game = False
                    elif again.lower() == "no" or again == "2":
                        print()
                        print("Game Over.")
                        done = True
                        sys.exit()
                        
                    else:
                        print()
                        print("Incorrect response - try again.")
                        time.sleep(2)
                        print()
                        check = False

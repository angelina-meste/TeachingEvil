def question1(exam: int) -> str:
    if exam == 1503:
        return "Correct!"
    else:
        return "Wrong."

def question2(exam: str) -> str:
    if exam.lower() == "animal" or exam.lower() == "animal kingdom" or exam.lower() == "animalia":
        return "Correct!"
    else:
        return "Wrong."

def question3(exam: str) -> str:
    if exam.lower() == "robert hooke":
        return "Correct!"
    else:
        return "Wrong."

def question4(exam: int) -> str:
    if exam == 9:
        return "Correct!"
    else:
        return "Wrong."

def question5(exam: int) -> str:
    if exam == 3:
        return "Correct!"
    else:
        return "Wrong."
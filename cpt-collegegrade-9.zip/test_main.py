from college_testb import *

def test_college():
    assert question1(1503) == "Correct!"
    assert question1(0) == "Wrong."
    
    assert question2("animal") == "Correct!"
    assert question2("animalia") == "Correct!"
    assert question2("animal kingdom") == "Correct!"
    assert question2("AnimAl") == "Correct!"
    assert question2("Beep") == "Wrong."
    assert question2("beep") == "Wrong."

    assert question3("robert hooke") == "Correct!"
    assert question3("Robert Hooke") == "Correct!"
    assert question3("roobert hoke") == "Wrong."

    assert question4(9) == "Correct!"
    assert question4(10) == "Wrong."

    assert question5(3) == "Correct!"
    assert question5(0) == "Wrong."
from college import *
from grade_9 import *

if __name__ == "__main__":
    begin()
    boss()
